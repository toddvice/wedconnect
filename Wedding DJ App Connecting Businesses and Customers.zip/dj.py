from flask import Blueprint, request, jsonify
from src.models.user import db, DJProfile, User, MusicGenre, PricingPackage, Service, Equipment, PortfolioItem, TeamMember, Availability
from src.routes.user import token_required
from datetime import datetime
import json

dj_bp = Blueprint('dj', __name__)

@dj_bp.route('/search', methods=['GET'])
def search_djs():
    # Get search parameters from query string
    location = request.args.get('location')
    date = request.args.get('date')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    genre = request.args.get('genre')
    min_experience = request.args.get('min_experience', type=int)
    
    # Base query
    query = DJProfile.query
    
    # Apply filters
    if location:
        # This is a simplified location search - in a real app, you'd use geocoding and distance calculation
        query = query.filter(DJProfile.user.has(User.customer_profile.has(location.contains(location))))
    
    if date:
        try:
            search_date = datetime.strptime(date, '%Y-%m-%d').date()
            # Find DJs available on the specified date
            query = query.join(Availability).filter(
                Availability.date == search_date,
                Availability.is_available == True
            )
        except ValueError:
            return jsonify({'message': 'Invalid date format. Use YYYY-MM-DD'}), 400
    
    if min_price is not None:
        query = query.join(PricingPackage).filter(PricingPackage.price >= min_price)
    
    if max_price is not None:
        query = query.join(PricingPackage).filter(PricingPackage.price <= max_price)
    
    if genre:
        query = query.join(DJProfile.music_genres).filter(MusicGenre.name == genre)
    
    if min_experience is not None:
        query = query.filter(DJProfile.years_of_experience >= min_experience)
    
    # Execute query and get results
    dj_profiles = query.all()
    
    # Format results
    results = []
    for profile in dj_profiles:
        user = User.query.get(profile.user_id)
        
        # Get pricing packages
        packages = PricingPackage.query.filter_by(dj_profile_id=profile.id).all()
        pricing = [{'id': pkg.id, 'name': pkg.name, 'price': pkg.price, 'hours': pkg.hours} for pkg in packages]
        
        # Get genres
        genres = [genre.name for genre in profile.music_genres]
        
        # Calculate average rating
        avg_rating = 0
        review_count = len(profile.reviews)
        if review_count > 0:
            avg_rating = sum(review.rating for review in profile.reviews) / review_count
        
        results.append({
            'id': profile.id,
            'user_id': user.uuid,
            'company_name': profile.company_name,
            'logo_url': profile.logo_url,
            'description': profile.description,
            'years_of_experience': profile.years_of_experience,
            'website': profile.website,
            'subscription_tier': profile.subscription_tier,
            'pricing': pricing,
            'genres': genres,
            'avg_rating': avg_rating,
            'review_count': review_count
        })
    
    return jsonify(results), 200

@dj_bp.route('/<uuid:user_id>', methods=['GET'])
def get_dj_profile(user_id):
    user = User.query.filter_by(uuid=str(user_id)).first()
    
    if not user or user.user_type != 'dj' or not user.dj_profile:
        return jsonify({'message': 'DJ profile not found'}), 404
    
    profile = user.dj_profile
    
    # Get team members
    team_members = TeamMember.query.filter_by(dj_profile_id=profile.id).all()
    team = [
        {
            'id': member.id,
            'name': member.name,
            'role': member.role,
            'bio': member.bio,
            'photo_url': member.photo_url,
            'years_of_experience': member.years_of_experience
        } for member in team_members
    ]
    
    # Get genres
    genres = [genre.name for genre in profile.music_genres]
    
    # Get equipment
    equipment = Equipment.query.filter_by(dj_profile_id=profile.id).all()
    equipment_list = [
        {
            'id': item.id,
            'name': item.name,
            'description': item.description,
            'photo_url': item.photo_url
        } for item in equipment
    ]
    
    # Get services
    services = Service.query.filter_by(dj_profile_id=profile.id).all()
    service_list = [
        {
            'id': service.id,
            'name': service.name,
            'description': service.description,
            'is_addon': service.is_addon,
            'price': service.price
        } for service in services
    ]
    
    # Get pricing packages
    packages = PricingPackage.query.filter_by(dj_profile_id=profile.id).all()
    pricing = [
        {
            'id': pkg.id,
            'name': pkg.name,
            'description': pkg.description,
            'price': pkg.price,
            'hours': pkg.hours,
            'is_custom': pkg.is_custom
        } for pkg in packages
    ]
    
    # Get portfolio items
    portfolio = PortfolioItem.query.filter_by(dj_profile_id=profile.id).all()
    portfolio_items = [
        {
            'id': item.id,
            'title': item.title,
            'description': item.description,
            'media_type': item.media_type,
            'media_url': item.media_url,
            'event_date': item.event_date.isoformat() if item.event_date else None,
            'event_type': item.event_type
        } for item in portfolio
    ]
    
    # Get reviews
    reviews = []
    for review in profile.reviews:
        customer = User.query.get(review.customer.user_id)
        reviews.append({
            'id': review.id,
            'rating': review.rating,
            'content': review.content,
            'response': review.response,
            'customer_name': f"{customer.first_name} {customer.last_name[0]}.",
            'created_at': review.created_at.isoformat()
        })
    
    # Calculate average rating
    avg_rating = 0
    review_count = len(profile.reviews)
    if review_count > 0:
        avg_rating = sum(review.rating for review in profile.reviews) / review_count
    
    # Format response
    result = {
        'id': profile.id,
        'user_id': user.uuid,
        'company_name': profile.company_name,
        'logo_url': profile.logo_url,
        'description': profile.description,
        'years_of_experience': profile.years_of_experience,
        'website': profile.website,
        'social_media': profile.social_media,
        'subscription_tier': profile.subscription_tier,
        'team_members': team,
        'genres': genres,
        'equipment': equipment_list,
        'services': service_list,
        'pricing_packages': pricing,
        'portfolio': portfolio_items,
        'reviews': reviews,
        'avg_rating': avg_rating,
        'review_count': review_count
    }
    
    return jsonify(result), 200

@dj_bp.route('/profile/genres', methods=['POST'])
@token_required
def update_genres(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'genres' not in data:
        return jsonify({'message': 'Genres list is required'}), 400
    
    profile = current_user.dj_profile
    
    # Clear existing genres
    profile.music_genres = []
    
    # Add new genres
    for genre_name in data['genres']:
        # Check if genre exists, create if not
        genre = MusicGenre.query.filter_by(name=genre_name).first()
        if not genre:
            genre = MusicGenre(name=genre_name)
            db.session.add(genre)
        
        profile.music_genres.append(genre)
    
    db.session.commit()
    
    return jsonify({'message': 'Genres updated successfully'}), 200

@dj_bp.route('/profile/team', methods=['POST'])
@token_required
def add_team_member(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({'message': 'Team member name is required'}), 400
    
    new_member = TeamMember(
        dj_profile_id=current_user.dj_profile.id,
        name=data['name'],
        role=data.get('role'),
        bio=data.get('bio'),
        photo_url=data.get('photo_url'),
        years_of_experience=data.get('years_of_experience')
    )
    
    db.session.add(new_member)
    db.session.commit()
    
    return jsonify({
        'message': 'Team member added successfully',
        'id': new_member.id
    }), 201

@dj_bp.route('/profile/team/<int:member_id>', methods=['PUT', 'DELETE'])
@token_required
def manage_team_member(current_user, member_id):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    member = TeamMember.query.filter_by(id=member_id, dj_profile_id=current_user.dj_profile.id).first()
    if not member:
        return jsonify({'message': 'Team member not found'}), 404
    
    if request.method == 'DELETE':
        db.session.delete(member)
        db.session.commit()
        return jsonify({'message': 'Team member deleted successfully'}), 200
    
    # PUT method
    data = request.get_json()
    
    if 'name' in data:
        member.name = data['name']
    if 'role' in data:
        member.role = data['role']
    if 'bio' in data:
        member.bio = data['bio']
    if 'photo_url' in data:
        member.photo_url = data['photo_url']
    if 'years_of_experience' in data:
        member.years_of_experience = data['years_of_experience']
    
    db.session.commit()
    
    return jsonify({'message': 'Team member updated successfully'}), 200

@dj_bp.route('/profile/equipment', methods=['POST'])
@token_required
def add_equipment(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({'message': 'Equipment name is required'}), 400
    
    new_equipment = Equipment(
        dj_profile_id=current_user.dj_profile.id,
        name=data['name'],
        description=data.get('description'),
        photo_url=data.get('photo_url')
    )
    
    db.session.add(new_equipment)
    db.session.commit()
    
    return jsonify({
        'message': 'Equipment added successfully',
        'id': new_equipment.id
    }), 201

@dj_bp.route('/profile/services', methods=['POST'])
@token_required
def add_service(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'name' not in data or 'price' not in data:
        return jsonify({'message': 'Service name and price are required'}), 400
    
    new_service = Service(
        dj_profile_id=current_user.dj_profile.id,
        name=data['name'],
        description=data.get('description'),
        is_addon=data.get('is_addon', False),
        price=data['price']
    )
    
    db.session.add(new_service)
    db.session.commit()
    
    return jsonify({
        'message': 'Service added successfully',
        'id': new_service.id
    }), 201

@dj_bp.route('/profile/packages', methods=['POST'])
@token_required
def add_package(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'name' not in data or 'price' not in data:
        return jsonify({'message': 'Package name and price are required'}), 400
    
    new_package = PricingPackage(
        dj_profile_id=current_user.dj_profile.id,
        name=data['name'],
        description=data.get('description'),
        price=data['price'],
        hours=data.get('hours'),
        is_custom=data.get('is_custom', False)
    )
    
    db.session.add(new_package)
    
    # Add included services if provided
    if 'service_ids' in data and isinstance(data['service_ids'], list):
        for service_id in data['service_ids']:
            service = Service.query.filter_by(id=service_id, dj_profile_id=current_user.dj_profile.id).first()
            if service:
                new_package.included_services.append(service)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Package added successfully',
        'id': new_package.id
    }), 201

@dj_bp.route('/profile/portfolio', methods=['POST'])
@token_required
def add_portfolio_item(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'title' not in data or 'media_type' not in data or 'media_url' not in data:
        return jsonify({'message': 'Title, media type, and media URL are required'}), 400
    
    # Validate media type
    if data['media_type'] not in ['image', 'video', 'audio']:
        return jsonify({'message': 'Media type must be image, video, or audio'}), 400
    
    # Parse event date if provided
    event_date = None
    if 'event_date' in data and data['event_date']:
        try:
            event_date = datetime.strptime(data['event_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'message': 'Invalid date format. Use YYYY-MM-DD'}), 400
    
    new_item = PortfolioItem(
        dj_profile_id=current_user.dj_profile.id,
        title=data['title'],
        description=data.get('description'),
        media_type=data['media_type'],
        media_url=data['media_url'],
        event_date=event_date,
        event_type=data.get('event_type')
    )
    
    db.session.add(new_item)
    db.session.commit()
    
    return jsonify({
        'message': 'Portfolio item added successfully',
        'id': new_item.id
    }), 201

@dj_bp.route('/profile/availability', methods=['POST'])
@token_required
def update_availability(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'dates' not in data or not isinstance(data['dates'], list):
        return jsonify({'message': 'Dates list is required'}), 400
    
    profile_id = current_user.dj_profile.id
    
    for date_info in data['dates']:
        if 'date' not in date_info or 'available' not in date_info:
            continue
        
        try:
            availability_date = datetime.strptime(date_info['date'], '%Y-%m-%d').date()
        except ValueError:
            continue
        
        # Check if availability record exists
        availability = Availability.query.filter_by(
            dj_profile_id=profile_id,
            date=availability_date
        ).first()
        
        if availability:
            # Update existing record
            availability.is_available = date_info['available']
        else:
            # Create new record
            availability = Availability(
                dj_profile_id=profile_id,
                date=availability_date,
                is_available=date_info['available']
            )
            db.session.add(availability)
    
    db.session.commit()
    
    return jsonify({'message': 'Availability updated successfully'}), 200

@dj_bp.route('/profile/availability', methods=['GET'])
@token_required
def get_availability(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get date range from query parameters
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    
    if not start_date_str or not end_date_str:
        return jsonify({'message': 'Start date and end date are required'}), 400
    
    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
    except ValueError:
        return jsonify({'message': 'Invalid date format. Use YYYY-MM-DD'}), 400
    
    # Get availability records
    availability_records = Availability.query.filter(
        Availability.dj_profile_id == current_user.dj_profile.id,
        Availability.date >= start_date,
        Availability.date <= end_date
    ).all()
    
    # Format results
    availability = [
        {
            'date': record.date.isoformat(),
            'available': record.is_available
        } for record in availability_records
    ]
    
    return jsonify(availability), 200
