from flask import Blueprint, request, jsonify
from src.models.user import db, User, Message
from src.routes.user import token_required
from datetime import datetime

message_bp = Blueprint('message', __name__)

@message_bp.route('/send', methods=['POST'])
@token_required
def send_message(current_user):
    data = request.get_json()
    
    # Validate required fields
    if not data or 'receiver_id' not in data or 'content' not in data:
        return jsonify({'message': 'Receiver ID and content are required'}), 400
    
    # Get receiver
    receiver = User.query.filter_by(uuid=data['receiver_id']).first()
    if not receiver:
        return jsonify({'message': 'Receiver not found'}), 404
    
    # Create message
    new_message = Message(
        sender_id=current_user.id,
        receiver_id=receiver.id,
        related_booking_id=data.get('booking_id'),
        content=data['content']
    )
    
    db.session.add(new_message)
    db.session.commit()
    
    return jsonify({
        'message': 'Message sent successfully',
        'id': new_message.id
    }), 201

@message_bp.route('/inbox', methods=['GET'])
@token_required
def get_inbox(current_user):
    # Get conversations (unique users who have exchanged messages with current user)
    sent_messages = Message.query.filter_by(sender_id=current_user.id).all()
    received_messages = Message.query.filter_by(receiver_id=current_user.id).all()
    
    # Extract unique user IDs from messages
    conversation_user_ids = set()
    for msg in sent_messages:
        conversation_user_ids.add(msg.receiver_id)
    for msg in received_messages:
        conversation_user_ids.add(msg.sender_id)
    
    # Get conversation previews
    conversations = []
    for user_id in conversation_user_ids:
        other_user = User.query.get(user_id)
        
        # Get latest message in conversation
        latest_message = Message.query.filter(
            ((Message.sender_id == current_user.id) & (Message.receiver_id == user_id)) |
            ((Message.sender_id == user_id) & (Message.receiver_id == current_user.id))
        ).order_by(Message.created_at.desc()).first()
        
        # Count unread messages
        unread_count = Message.query.filter_by(
            sender_id=user_id,
            receiver_id=current_user.id,
            is_read=False
        ).count()
        
        conversations.append({
            'user_id': other_user.uuid,
            'name': f"{other_user.first_name} {other_user.last_name}",
            'user_type': other_user.user_type,
            'latest_message': {
                'content': latest_message.content,
                'created_at': latest_message.created_at.isoformat(),
                'is_from_me': latest_message.sender_id == current_user.id
            },
            'unread_count': unread_count
        })
    
    # Sort conversations by latest message time (newest first)
    conversations.sort(key=lambda x: x['latest_message']['created_at'], reverse=True)
    
    return jsonify(conversations), 200

@message_bp.route('/conversation/<uuid:user_id>', methods=['GET'])
@token_required
def get_conversation(current_user, user_id):
    # Get other user
    other_user = User.query.filter_by(uuid=str(user_id)).first()
    if not other_user:
        return jsonify({'message': 'User not found'}), 404
    
    # Get messages between users
    messages = Message.query.filter(
        ((Message.sender_id == current_user.id) & (Message.receiver_id == other_user.id)) |
        ((Message.sender_id == other_user.id) & (Message.receiver_id == current_user.id))
    ).order_by(Message.created_at).all()
    
    # Format messages
    formatted_messages = []
    for msg in messages:
        formatted_messages.append({
            'id': msg.id,
            'content': msg.content,
            'is_from_me': msg.sender_id == current_user.id,
            'created_at': msg.created_at.isoformat(),
            'is_read': msg.is_read
        })
        
        # Mark received messages as read
        if msg.receiver_id == current_user.id and not msg.is_read:
            msg.is_read = True
    
    db.session.commit()
    
    return jsonify({
        'user': {
            'id': other_user.uuid,
            'name': f"{other_user.first_name} {other_user.last_name}",
            'user_type': other_user.user_type
        },
        'messages': formatted_messages
    }), 200
