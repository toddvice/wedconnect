from flask import Blueprint, request, jsonify, current_app
from src.models.user import db, User, DJProfile, CustomerProfile
from src.routes.user import user_bp
from src.routes.dj import dj_bp
from src.routes.booking import booking_bp
from src.routes.message import message_bp
from src.routes.subscription import subscription_bp
import os

api_bp = Blueprint('api', __name__)

# Register all blueprints
api_bp.register_blueprint(user_bp, url_prefix='/user')
api_bp.register_blueprint(dj_bp, url_prefix='/dj')
api_bp.register_blueprint(booking_bp, url_prefix='/booking')
api_bp.register_blueprint(message_bp, url_prefix='/message')
api_bp.register_blueprint(subscription_bp, url_prefix='/subscription')

@api_bp.route('/health', methods=['GET'])
def health_check():
    """API health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'version': '1.0.0'
    }), 200

@api_bp.route('/genres', methods=['GET'])
def get_genres():
    """Get all music genres"""
    from src.models.user import MusicGenre
    genres = MusicGenre.query.all()
    return jsonify([genre.name for genre in genres]), 200

@api_bp.route('/stats', methods=['GET'])
def get_stats():
    """Get marketplace statistics"""
    dj_count = DJProfile.query.count()
    customer_count = CustomerProfile.query.count()
    
    # In a real app, you would calculate these from actual data
    # For this demo, we'll use mock data
    stats = {
        'dj_count': dj_count,
        'customer_count': customer_count,
        'booking_count': 1250,
        'average_rating': 4.8,
        'total_events_completed': 950,
        'popular_genres': [
            {'name': 'Pop', 'percentage': 35},
            {'name': 'Hip Hop', 'percentage': 25},
            {'name': 'Electronic', 'percentage': 20},
            {'name': 'R&B', 'percentage': 15},
            {'name': 'Rock', 'percentage': 5}
        ]
    }
    
    return jsonify(stats), 200
