from flask import Blueprint, request, jsonify
from src.models.user import db, User, DJProfile, CustomerProfile, Subscription
from src.routes.user import token_required
from datetime import datetime, timedelta
import uuid

subscription_bp = Blueprint('subscription', __name__)

@subscription_bp.route('/dj/plans', methods=['GET'])
def get_subscription_plans():
    """Get available subscription plans for DJ companies"""
    plans = [
        {
            'id': 'basic',
            'name': 'Basic',
            'price': 0,
            'billing_cycle': 'monthly',
            'features': [
                'Limited profile visibility',
                'Basic listing with minimal information',
                'Limited number of portfolio items (3)',
                'Standard placement in search results',
                'Maximum of 3 active booking requests per month'
            ]
        },
        {
            'id': 'professional',
            'name': 'Professional',
            'price': 49,
            'billing_cycle': 'monthly',
            'features': [
                'Enhanced profile visibility',
                'Comprehensive profile with unlimited portfolio items',
                'Equipment and services showcase',
                'Higher placement in search results',
                'Unlimited booking requests',
                'Basic analytics dashboard',
                'Verified badge on profile'
            ]
        },
        {
            'id': 'premium',
            'name': 'Premium',
            'price': 99,
            'billing_cycle': 'monthly',
            'features': [
                'Featured placement in search results and homepage',
                'Priority customer support',
                'Advanced analytics and performance metrics',
                'Custom branding options',
                'Promotional tools (special offers, discounts)',
                'Calendar integration with external systems',
                'Competitor analysis tools',
                'Early access to new features',
                'Reduced commission rates (3% vs standard 5%)'
            ]
        }
    ]
    
    return jsonify(plans), 200

@subscription_bp.route('/dj/subscribe', methods=['POST'])
@token_required
def subscribe_dj(current_user):
    """Subscribe DJ to a paid plan"""
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'plan_id' not in data:
        return jsonify({'message': 'Plan ID is required'}), 400
    
    plan_id = data['plan_id']
    if plan_id not in ['basic', 'professional', 'premium']:
        return jsonify({'message': 'Invalid plan ID'}), 400
    
    # Get price based on plan
    price = 0
    if plan_id == 'professional':
        price = 49
    elif plan_id == 'premium':
        price = 99
    
    # In a real app, you would process payment here
    # For this demo, we'll simulate a successful payment
    payment_id = f"SUB-{uuid.uuid4().hex[:8].upper()}"
    
    # Calculate subscription end date (1 month from now)
    end_date = datetime.utcnow() + timedelta(days=30)
    
    # Create subscription record
    new_subscription = Subscription(
        dj_id=current_user.dj_profile.id,
        tier=plan_id,
        end_date=end_date,
        payment_id=payment_id,
        amount_paid=price
    )
    
    db.session.add(new_subscription)
    
    # Update DJ profile with subscription tier
    current_user.dj_profile.subscription_tier = plan_id
    current_user.dj_profile.subscription_expiry = end_date
    
    db.session.commit()
    
    return jsonify({
        'message': 'Subscription successful',
        'plan': plan_id,
        'expiry_date': end_date.isoformat()
    }), 200

@subscription_bp.route('/customer/premium', methods=['POST'])
@token_required
def upgrade_customer(current_user):
    """Upgrade customer to premium status"""
    if current_user.user_type != 'customer' or not current_user.customer_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # In a real app, you would process payment here
    # For this demo, we'll simulate a successful payment
    payment_id = f"PREM-{uuid.uuid4().hex[:8].upper()}"
    
    # Set premium status for 30 days
    premium_until = datetime.utcnow() + timedelta(days=30)
    
    # Update customer profile
    current_user.customer_profile.is_premium = True
    current_user.customer_profile.premium_until = premium_until
    
    db.session.commit()
    
    return jsonify({
        'message': 'Premium upgrade successful',
        'premium_until': premium_until.isoformat()
    }), 200

@subscription_bp.route('/dj/promotions', methods=['POST'])
@token_required
def create_promotion(current_user):
    """Create a promoted listing for a DJ"""
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data or 'promotion_type' not in data:
        return jsonify({'message': 'Promotion type is required'}), 400
    
    promotion_type = data['promotion_type']
    
    # Calculate price based on promotion type
    price = 0
    duration_days = 0
    
    if promotion_type == 'featured_week':
        price = 25
        duration_days = 7
        promotion_name = 'Featured DJ (1 week)'
    elif promotion_type == 'homepage_spotlight':
        price = 150
        duration_days = 7
        promotion_name = 'Homepage Spotlight (1 week)'
    else:
        return jsonify({'message': 'Invalid promotion type'}), 400
    
    # In a real app, you would process payment and create a promotion record here
    # For this demo, we'll simulate a successful payment
    payment_id = f"PROMO-{uuid.uuid4().hex[:8].upper()}"
    
    # Calculate promotion end date
    end_date = datetime.utcnow() + timedelta(days=duration_days)
    
    # In a real implementation, you would store this promotion in the database
    # For this demo, we'll just return success
    
    return jsonify({
        'message': 'Promotion created successfully',
        'promotion': promotion_name,
        'end_date': end_date.isoformat(),
        'payment_id': payment_id
    }), 200

@subscription_bp.route('/dj/analytics', methods=['GET'])
@token_required
def get_dj_analytics(current_user):
    """Get analytics for DJ profile (premium feature)"""
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Check subscription tier
    if current_user.dj_profile.subscription_tier == 'basic':
        return jsonify({'message': 'Analytics are only available for Professional and Premium subscribers'}), 403
    
    # In a real app, you would query actual analytics data
    # For this demo, we'll return mock data
    
    # Basic analytics for Professional tier
    analytics = {
        'profile_views': 127,
        'booking_requests': 8,
        'conversion_rate': 6.3,
        'average_rating': 4.7
    }
    
    # Additional analytics for Premium tier
    if current_user.dj_profile.subscription_tier == 'premium':
        analytics.update({
            'competitor_comparison': {
                'average_price': {
                    'you': 850,
                    'market_average': 920
                },
                'average_rating': {
                    'you': 4.7,
                    'market_average': 4.2
                },
                'booking_frequency': {
                    'you': 8,
                    'market_average': 6
                }
            },
            'customer_demographics': {
                'age_groups': {
                    '18-24': 15,
                    '25-34': 45,
                    '35-44': 30,
                    '45+': 10
                },
                'event_types': {
                    'wedding': 75,
                    'corporate': 15,
                    'birthday': 10
                }
            }
        })
    
    return jsonify(analytics), 200

@subscription_bp.route('/customer/concierge', methods=['POST'])
@token_required
def request_concierge(current_user):
    """Request concierge DJ matching service (premium customer feature)"""
    if current_user.user_type != 'customer' or not current_user.customer_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Check if customer is premium
    if not current_user.customer_profile.is_premium:
        return jsonify({'message': 'Concierge service is only available for Premium customers'}), 403
    
    data = request.get_json()
    if not data:
        return jsonify({'message': 'Request details are required'}), 400
    
    # In a real app, you would create a concierge request record
    # For this demo, we'll just return success
    
    return jsonify({
        'message': 'Concierge request submitted successfully',
        'estimated_response_time': '24 hours'
    }), 200

@subscription_bp.route('/transaction-fees', methods=['GET'])
def get_transaction_fees():
    """Get transaction fee information"""
    fees = {
        'dj_commission': {
            'basic': '5% of booking total',
            'professional': '5% of booking total',
            'premium': '3% of booking total'
        },
        'customer_convenience_fee': {
            'standard': '2.5% of booking total',
            'premium': 'Waived'
        },
        'payment_processing': '2.9% + $0.30 per transaction',
        'expedited_payout': '2% fee for 24-hour payout'
    }
    
    return jsonify(fees), 200
