from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import uuid

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    user_type = db.Column(db.String(10), nullable=False)  # 'dj' or 'customer'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    dj_profile = db.relationship('DJProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    customer_profile = db.relationship('CustomerProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.email}>'


class DJProfile(db.Model):
    __tablename__ = 'dj_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    company_name = db.Column(db.String(100), nullable=False)
    logo_url = db.Column(db.String(255), nullable=True)
    description = db.Column(db.Text, nullable=True)
    years_of_experience = db.Column(db.Integer, nullable=True)
    website = db.Column(db.String(255), nullable=True)
    social_media = db.Column(db.JSON, nullable=True)  # Store social media links as JSON
    subscription_tier = db.Column(db.String(20), default='basic')  # 'basic', 'professional', 'premium'
    subscription_expiry = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    team_members = db.relationship('TeamMember', backref='dj_profile', cascade='all, delete-orphan')
    music_genres = db.relationship('MusicGenre', secondary='dj_genres', backref='dj_profiles')
    equipment = db.relationship('Equipment', backref='dj_profile', cascade='all, delete-orphan')
    services = db.relationship('Service', backref='dj_profile', cascade='all, delete-orphan')
    pricing_packages = db.relationship('PricingPackage', backref='dj_profile', cascade='all, delete-orphan')
    portfolio_items = db.relationship('PortfolioItem', backref='dj_profile', cascade='all, delete-orphan')
    availability = db.relationship('Availability', backref='dj_profile', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<DJProfile {self.company_name}>'


class CustomerProfile(db.Model):
    __tablename__ = 'customer_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    wedding_date = db.Column(db.Date, nullable=True)
    wedding_location = db.Column(db.String(255), nullable=True)
    guest_count = db.Column(db.Integer, nullable=True)
    budget = db.Column(db.Float, nullable=True)
    is_premium = db.Column(db.Boolean, default=False)
    premium_until = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    favorite_djs = db.relationship('DJProfile', secondary='customer_favorites', backref='favorited_by')
    
    def __repr__(self):
        return f'<CustomerProfile {self.user_id}>'


class TeamMember(db.Model):
    __tablename__ = 'team_members'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_profile_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(100), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    photo_url = db.Column(db.String(255), nullable=True)
    years_of_experience = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class MusicGenre(db.Model):
    __tablename__ = 'music_genres'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    
    def __repr__(self):
        return f'<MusicGenre {self.name}>'


# Association table for DJ profiles and music genres
dj_genres = db.Table('dj_genres',
    db.Column('dj_profile_id', db.Integer, db.ForeignKey('dj_profiles.id'), primary_key=True),
    db.Column('genre_id', db.Integer, db.ForeignKey('music_genres.id'), primary_key=True)
)


class Equipment(db.Model):
    __tablename__ = 'equipment'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_profile_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    photo_url = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Service(db.Model):
    __tablename__ = 'services'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_profile_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    is_addon = db.Column(db.Boolean, default=False)
    price = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PricingPackage(db.Model):
    __tablename__ = 'pricing_packages'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_profile_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False)
    hours = db.Column(db.Integer, nullable=True)
    is_custom = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    included_services = db.relationship('Service', secondary='package_services', backref='packages')


# Association table for packages and services
package_services = db.Table('package_services',
    db.Column('package_id', db.Integer, db.ForeignKey('pricing_packages.id'), primary_key=True),
    db.Column('service_id', db.Integer, db.ForeignKey('services.id'), primary_key=True)
)


class PortfolioItem(db.Model):
    __tablename__ = 'portfolio_items'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_profile_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    media_type = db.Column(db.String(10), nullable=False)  # 'image', 'video', 'audio'
    media_url = db.Column(db.String(255), nullable=False)
    event_date = db.Column(db.Date, nullable=True)
    event_type = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Availability(db.Model):
    __tablename__ = 'availability'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_profile_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    is_available = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (db.UniqueConstraint('dj_profile_id', 'date', name='unique_dj_date'),)


# Association table for customer favorites
customer_favorites = db.Table('customer_favorites',
    db.Column('customer_profile_id', db.Integer, db.ForeignKey('customer_profiles.id'), primary_key=True),
    db.Column('dj_profile_id', db.Integer, db.ForeignKey('dj_profiles.id'), primary_key=True)
)


class Booking(db.Model):
    __tablename__ = 'bookings'
    
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    customer_id = db.Column(db.Integer, db.ForeignKey('customer_profiles.id'), nullable=False)
    dj_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    event_start_time = db.Column(db.Time, nullable=False)
    event_end_time = db.Column(db.Time, nullable=False)
    event_location = db.Column(db.String(255), nullable=False)
    event_type = db.Column(db.String(50), nullable=True)
    package_id = db.Column(db.Integer, db.ForeignKey('pricing_packages.id'), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='pending')  # 'pending', 'confirmed', 'completed', 'cancelled'
    total_price = db.Column(db.Float, nullable=False)
    deposit_amount = db.Column(db.Float, nullable=True)
    deposit_paid = db.Column(db.Boolean, default=False)
    balance_paid = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    customer = db.relationship('CustomerProfile', backref='bookings')
    dj = db.relationship('DJProfile', backref='bookings')
    package = db.relationship('PricingPackage', backref='bookings')
    payments = db.relationship('Payment', backref='booking', cascade='all, delete-orphan')
    contract = db.relationship('Contract', backref='booking', uselist=False, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Booking {self.uuid}>'


class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_type = db.Column(db.String(20), nullable=False)  # 'deposit', 'balance', 'full', 'gratuity'
    payment_method = db.Column(db.String(20), nullable=False)  # 'credit_card', 'bank_transfer', etc.
    transaction_id = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(20), nullable=False)  # 'pending', 'completed', 'failed', 'refunded'
    platform_fee = db.Column(db.Float, nullable=False)
    dj_payout = db.Column(db.Float, nullable=False)
    payout_status = db.Column(db.String(20), default='pending')  # 'pending', 'completed'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Contract(db.Model):
    __tablename__ = 'contracts'
    
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    customer_signed = db.Column(db.Boolean, default=False)
    customer_signed_at = db.Column(db.DateTime, nullable=True)
    dj_signed = db.Column(db.Boolean, default=False)
    dj_signed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Message(db.Model):
    __tablename__ = 'messages'
    
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    related_booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=True)
    content = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sender = db.relationship('User', foreign_keys=[sender_id], backref='sent_messages')
    receiver = db.relationship('User', foreign_keys=[receiver_id], backref='received_messages')
    related_booking = db.relationship('Booking', backref='messages')


class Review(db.Model):
    __tablename__ = 'reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer_profiles.id'), nullable=False)
    dj_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    content = db.Column(db.Text, nullable=True)
    response = db.Column(db.Text, nullable=True)  # DJ's response to the review
    is_verified = db.Column(db.Boolean, default=True)  # Since it's tied to a booking, it's verified
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    booking = db.relationship('Booking', backref='review', uselist=False)
    customer = db.relationship('CustomerProfile', backref='reviews')
    dj = db.relationship('DJProfile', backref='reviews')
    
    def __repr__(self):
        return f'<Review {self.id} - Rating: {self.rating}>'


class Subscription(db.Model):
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    dj_id = db.Column(db.Integer, db.ForeignKey('dj_profiles.id'), nullable=False)
    tier = db.Column(db.String(20), nullable=False)  # 'basic', 'professional', 'premium'
    start_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    auto_renew = db.Column(db.Boolean, default=True)
    payment_id = db.Column(db.String(100), nullable=True)  # External payment reference
    amount_paid = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    dj = db.relationship('DJProfile', backref='subscriptions')
