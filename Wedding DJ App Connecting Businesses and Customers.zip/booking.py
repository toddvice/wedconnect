from flask import Blueprint, request, jsonify
from src.models.user import db, User, CustomerProfile, DJProfile, Booking, Payment, Contract, Review
from src.routes.user import token_required
from datetime import datetime
import uuid

booking_bp = Blueprint('booking', __name__)

@booking_bp.route('/request', methods=['POST'])
@token_required
def request_booking(current_user):
    if current_user.user_type != 'customer' or not current_user.customer_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['dj_id', 'event_date', 'event_start_time', 'event_end_time', 
                      'event_location', 'package_id']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Missing required field: {field}'}), 400
    
    # Get DJ profile
    dj_user = User.query.filter_by(uuid=data['dj_id']).first()
    if not dj_user or dj_user.user_type != 'dj' or not dj_user.dj_profile:
        return jsonify({'message': 'DJ not found'}), 404
    
    # Parse date and times
    try:
        event_date = datetime.strptime(data['event_date'], '%Y-%m-%d').date()
        event_start_time = datetime.strptime(data['event_start_time'], '%H:%M').time()
        event_end_time = datetime.strptime(data['event_end_time'], '%H:%M').time()
    except ValueError:
        return jsonify({'message': 'Invalid date or time format'}), 400
    
    # Get package
    package = None
    for pkg in dj_user.dj_profile.pricing_packages:
        if pkg.id == data['package_id']:
            package = pkg
            break
    
    if not package:
        return jsonify({'message': 'Package not found'}), 404
    
    # Calculate deposit amount (typically 25-50% of total)
    deposit_amount = package.price * 0.25
    
    # Create booking
    new_booking = Booking(
        customer_id=current_user.customer_profile.id,
        dj_id=dj_user.dj_profile.id,
        event_date=event_date,
        event_start_time=event_start_time,
        event_end_time=event_end_time,
        event_location=data['event_location'],
        event_type=data.get('event_type'),
        package_id=package.id,
        status='pending',
        total_price=package.price,
        deposit_amount=deposit_amount,
        notes=data.get('notes')
    )
    
    db.session.add(new_booking)
    db.session.commit()
    
    # Generate contract
    contract_content = f"""
    WEDDING DJ SERVICES AGREEMENT
    
    This agreement is made on {datetime.now().strftime('%B %d, %Y')} between:
    
    DJ: {dj_user.dj_profile.company_name}
    Customer: {current_user.first_name} {current_user.last_name}
    
    EVENT DETAILS:
    Date: {event_date.strftime('%B %d, %Y')}
    Start Time: {event_start_time.strftime('%I:%M %p')}
    End Time: {event_end_time.strftime('%I:%M %p')}
    Location: {data['event_location']}
    
    SERVICES:
    Package: {package.name}
    Price: ${package.price}
    
    PAYMENT TERMS:
    Deposit Amount: ${deposit_amount} (Due upon booking confirmation)
    Balance Due: ${package.price - deposit_amount} (Due 14 days before event)
    
    CANCELLATION POLICY:
    - Cancellations made 90+ days before the event: Full refund of deposit
    - Cancellations made 30-89 days before the event: 50% of deposit refunded
    - Cancellations made less than 30 days before the event: No refund
    
    ADDITIONAL TERMS:
    1. The DJ will arrive at least 1 hour before the start time for setup.
    2. The Customer will provide adequate power supply and reasonable protection from the elements.
    3. Any overtime beyond the contracted end time will be billed at an additional rate.
    
    This agreement represents the entire understanding between the parties.
    """
    
    new_contract = Contract(
        booking_id=new_booking.id,
        content=contract_content
    )
    
    db.session.add(new_contract)
    db.session.commit()
    
    return jsonify({
        'message': 'Booking request submitted successfully',
        'booking_id': new_booking.uuid
    }), 201

@booking_bp.route('/dj/pending', methods=['GET'])
@token_required
def get_dj_pending_bookings(current_user):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get pending bookings
    pending_bookings = Booking.query.filter_by(
        dj_id=current_user.dj_profile.id,
        status='pending'
    ).all()
    
    # Format results
    results = []
    for booking in pending_bookings:
        customer = User.query.get(booking.customer.user_id)
        package = booking.package
        
        results.append({
            'id': booking.uuid,
            'customer_name': f"{customer.first_name} {customer.last_name}",
            'event_date': booking.event_date.isoformat(),
            'event_start_time': booking.event_start_time.strftime('%H:%M'),
            'event_end_time': booking.event_end_time.strftime('%H:%M'),
            'event_location': booking.event_location,
            'event_type': booking.event_type,
            'package_name': package.name if package else None,
            'total_price': booking.total_price,
            'deposit_amount': booking.deposit_amount,
            'notes': booking.notes,
            'created_at': booking.created_at.isoformat()
        })
    
    return jsonify(results), 200

@booking_bp.route('/customer/bookings', methods=['GET'])
@token_required
def get_customer_bookings(current_user):
    if current_user.user_type != 'customer' or not current_user.customer_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get all customer bookings
    bookings = Booking.query.filter_by(
        customer_id=current_user.customer_profile.id
    ).all()
    
    # Format results
    results = []
    for booking in bookings:
        dj_user = User.query.get(booking.dj.user_id)
        package = booking.package
        
        results.append({
            'id': booking.uuid,
            'dj_name': booking.dj.company_name,
            'dj_id': dj_user.uuid,
            'event_date': booking.event_date.isoformat(),
            'event_start_time': booking.event_start_time.strftime('%H:%M'),
            'event_end_time': booking.event_end_time.strftime('%H:%M'),
            'event_location': booking.event_location,
            'event_type': booking.event_type,
            'package_name': package.name if package else None,
            'total_price': booking.total_price,
            'deposit_amount': booking.deposit_amount,
            'deposit_paid': booking.deposit_paid,
            'balance_paid': booking.balance_paid,
            'status': booking.status,
            'notes': booking.notes,
            'created_at': booking.created_at.isoformat()
        })
    
    return jsonify(results), 200

@booking_bp.route('/<uuid:booking_id>/confirm', methods=['POST'])
@token_required
def confirm_booking(current_user, booking_id):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get booking
    booking = Booking.query.filter_by(uuid=str(booking_id), dj_id=current_user.dj_profile.id).first()
    if not booking:
        return jsonify({'message': 'Booking not found'}), 404
    
    if booking.status != 'pending':
        return jsonify({'message': 'Booking is not in pending status'}), 400
    
    # Update booking status
    booking.status = 'confirmed'
    db.session.commit()
    
    return jsonify({'message': 'Booking confirmed successfully'}), 200

@booking_bp.route('/<uuid:booking_id>/cancel', methods=['POST'])
@token_required
def cancel_booking(current_user, booking_id):
    # Get booking
    booking = None
    
    if current_user.user_type == 'dj' and current_user.dj_profile:
        booking = Booking.query.filter_by(uuid=str(booking_id), dj_id=current_user.dj_profile.id).first()
    elif current_user.user_type == 'customer' and current_user.customer_profile:
        booking = Booking.query.filter_by(uuid=str(booking_id), customer_id=current_user.customer_profile.id).first()
    
    if not booking:
        return jsonify({'message': 'Booking not found'}), 404
    
    if booking.status == 'completed':
        return jsonify({'message': 'Cannot cancel a completed booking'}), 400
    
    # Update booking status
    booking.status = 'cancelled'
    db.session.commit()
    
    return jsonify({'message': 'Booking cancelled successfully'}), 200

@booking_bp.route('/<uuid:booking_id>/contract', methods=['GET'])
@token_required
def get_contract(current_user, booking_id):
    # Get booking
    booking = None
    
    if current_user.user_type == 'dj' and current_user.dj_profile:
        booking = Booking.query.filter_by(uuid=str(booking_id), dj_id=current_user.dj_profile.id).first()
    elif current_user.user_type == 'customer' and current_user.customer_profile:
        booking = Booking.query.filter_by(uuid=str(booking_id), customer_id=current_user.customer_profile.id).first()
    
    if not booking or not booking.contract:
        return jsonify({'message': 'Contract not found'}), 404
    
    return jsonify({
        'content': booking.contract.content,
        'customer_signed': booking.contract.customer_signed,
        'customer_signed_at': booking.contract.customer_signed_at.isoformat() if booking.contract.customer_signed_at else None,
        'dj_signed': booking.contract.dj_signed,
        'dj_signed_at': booking.contract.dj_signed_at.isoformat() if booking.contract.dj_signed_at else None
    }), 200

@booking_bp.route('/<uuid:booking_id>/contract/sign', methods=['POST'])
@token_required
def sign_contract(current_user, booking_id):
    # Get booking
    booking = None
    
    if current_user.user_type == 'dj' and current_user.dj_profile:
        booking = Booking.query.filter_by(uuid=str(booking_id), dj_id=current_user.dj_profile.id).first()
        if booking and booking.contract:
            booking.contract.dj_signed = True
            booking.contract.dj_signed_at = datetime.utcnow()
    elif current_user.user_type == 'customer' and current_user.customer_profile:
        booking = Booking.query.filter_by(uuid=str(booking_id), customer_id=current_user.customer_profile.id).first()
        if booking and booking.contract:
            booking.contract.customer_signed = True
            booking.contract.customer_signed_at = datetime.utcnow()
    
    if not booking or not booking.contract:
        return jsonify({'message': 'Contract not found'}), 404
    
    db.session.commit()
    
    return jsonify({'message': 'Contract signed successfully'}), 200

@booking_bp.route('/<uuid:booking_id>/payment', methods=['POST'])
@token_required
def process_payment(current_user, booking_id):
    if current_user.user_type != 'customer' or not current_user.customer_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get booking
    booking = Booking.query.filter_by(uuid=str(booking_id), customer_id=current_user.customer_profile.id).first()
    if not booking:
        return jsonify({'message': 'Booking not found'}), 404
    
    data = request.get_json()
    if not data or 'payment_type' not in data or 'payment_method' not in data:
        return jsonify({'message': 'Payment type and method are required'}), 400
    
    # Validate payment type
    payment_type = data['payment_type']
    if payment_type not in ['deposit', 'balance', 'full']:
        return jsonify({'message': 'Invalid payment type'}), 400
    
    # Calculate amount based on payment type
    amount = 0
    if payment_type == 'deposit':
        if booking.deposit_paid:
            return jsonify({'message': 'Deposit already paid'}), 400
        amount = booking.deposit_amount
    elif payment_type == 'balance':
        if not booking.deposit_paid:
            return jsonify({'message': 'Deposit must be paid first'}), 400
        if booking.balance_paid:
            return jsonify({'message': 'Balance already paid'}), 400
        amount = booking.total_price - booking.deposit_amount
    elif payment_type == 'full':
        if booking.deposit_paid or booking.balance_paid:
            return jsonify({'message': 'Partial payment already made'}), 400
        amount = booking.total_price
    
    # Calculate platform fee (5% of amount)
    platform_fee = amount * 0.05
    dj_payout = amount - platform_fee
    
    # In a real app, you would integrate with a payment processor here
    # For this demo, we'll simulate a successful payment
    transaction_id = f"TRANS-{uuid.uuid4().hex[:8].upper()}"
    
    # Create payment record
    new_payment = Payment(
        booking_id=booking.id,
        amount=amount,
        payment_type=payment_type,
        payment_method=data['payment_method'],
        transaction_id=transaction_id,
        status='completed',
        platform_fee=platform_fee,
        dj_payout=dj_payout
    )
    
    db.session.add(new_payment)
    
    # Update booking payment status
    if payment_type == 'deposit' or payment_type == 'full':
        booking.deposit_paid = True
    if payment_type == 'balance' or payment_type == 'full':
        booking.balance_paid = True
    
    # If both deposit and balance are paid, mark booking as confirmed
    if booking.deposit_paid and booking.balance_paid and booking.status == 'pending':
        booking.status = 'confirmed'
    
    db.session.commit()
    
    return jsonify({
        'message': 'Payment processed successfully',
        'transaction_id': transaction_id,
        'amount': amount,
        'payment_type': payment_type
    }), 200

@booking_bp.route('/<uuid:booking_id>/review', methods=['POST'])
@token_required
def add_review(current_user, booking_id):
    if current_user.user_type != 'customer' or not current_user.customer_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get booking
    booking = Booking.query.filter_by(uuid=str(booking_id), customer_id=current_user.customer_profile.id).first()
    if not booking:
        return jsonify({'message': 'Booking not found'}), 404
    
    # Check if booking is completed
    if booking.status != 'completed':
        return jsonify({'message': 'Can only review completed bookings'}), 400
    
    # Check if review already exists
    if booking.review:
        return jsonify({'message': 'Review already submitted for this booking'}), 400
    
    data = request.get_json()
    if not data or 'rating' not in data:
        return jsonify({'message': 'Rating is required'}), 400
    
    # Validate rating
    rating = data['rating']
    if not isinstance(rating, int) or rating < 1 or rating > 5:
        return jsonify({'message': 'Rating must be an integer between 1 and 5'}), 400
    
    # Create review
    new_review = Review(
        booking_id=booking.id,
        customer_id=booking.customer_id,
        dj_id=booking.dj_id,
        rating=rating,
        content=data.get('content')
    )
    
    db.session.add(new_review)
    db.session.commit()
    
    return jsonify({'message': 'Review submitted successfully'}), 201

@booking_bp.route('/dj/reviews/<int:review_id>/respond', methods=['POST'])
@token_required
def respond_to_review(current_user, review_id):
    if current_user.user_type != 'dj' or not current_user.dj_profile:
        return jsonify({'message': 'Access denied'}), 403
    
    # Get review
    review = Review.query.filter_by(id=review_id, dj_id=current_user.dj_profile.id).first()
    if not review:
        return jsonify({'message': 'Review not found'}), 404
    
    data = request.get_json()
    if not data or 'response' not in data:
        return jsonify({'message': 'Response content is required'}), 400
    
    # Update review with response
    review.response = data['response']
    db.session.commit()
    
    return jsonify({'message': 'Response added successfully'}), 200
